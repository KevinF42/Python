<h3>
<pre>
Minecraft-Pi python examples. CW Coleman
Both the yamoto.py and the startship.py are my first 
attempts at making objects
using Minecraft-Pi  python.

Both examples are experiments so I could learn some 
of the basics in Minecraft-Pi python scripting.

Have fun.

</pre>
</h3>
